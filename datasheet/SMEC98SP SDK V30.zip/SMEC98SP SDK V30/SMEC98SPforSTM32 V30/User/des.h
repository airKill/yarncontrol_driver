void encrypt(unsigned char *input, unsigned char *key, unsigned char *output);
void decrypt(unsigned char *input, unsigned char *key, unsigned char *output);
void TripleDES(unsigned char *input, unsigned char *key, unsigned char *output);
void TripleDES_1(unsigned char *input, unsigned char *key, unsigned char *output);
void calMAC_3DES(unsigned char *input, unsigned int uiLen, unsigned char *key, unsigned char *output);

