	word data  				SW;

	byte data  				I2C_State;
	byte data  				I2C_count_bytes;
	byte data  				I2C_send_bytes;
	byte xdata 				I2C_Buf[256];
	byte xdata				Random_Number[8];
	
